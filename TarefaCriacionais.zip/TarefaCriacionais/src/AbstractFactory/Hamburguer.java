package AbstractFactory;

public interface Hamburguer {
	void exibirInfoBurguer();
}
