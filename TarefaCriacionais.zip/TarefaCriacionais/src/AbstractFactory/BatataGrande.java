package AbstractFactory;

public class BatataGrande implements BatataFrita{
	public void exibirInfoBatata() {
		System.out.println("Nome: Batata Frita Grande \nFranquia: Burguer King\nproduto: Batata Frita");
	}
}
