package AbstractFactory;

public class BatataFina implements BatataFrita{
	public void exibirInfoBatata() {
		System.out.println("Nome: Batata Frita Fina \nFranquia: McDonalds\nproduto: Batata Frita");
	}
}
