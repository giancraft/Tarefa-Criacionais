package AbstractFactory;

public interface BatataFrita {
	void exibirInfoBatata();
}
