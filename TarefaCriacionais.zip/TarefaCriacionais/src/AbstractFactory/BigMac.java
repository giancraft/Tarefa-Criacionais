package AbstractFactory;

public class BigMac implements Hamburguer{
	public void exibirInfoBurguer() {
		System.out.println("Nome: Big Mac \nFranquia: McDonalds\nproduto: Hamburguer");
	}
}
