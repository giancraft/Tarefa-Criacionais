package AbstractFactory;

public interface FabricaDeFastFood {
	Hamburguer criarHamburguer();
	BatataFrita criarBatataFrita();
}
