package AbstractFactory;

public class Whopper implements Hamburguer{
	public void exibirInfoBurguer() {
		System.out.println("Nome: Whopper\nFranquia: Burguer King\nproduto: Hamburguer");
	}
}