package factoryMethod2;

public interface IFactoryVillager {
	public Villager criarVillager(String nome, String profissao);
}
