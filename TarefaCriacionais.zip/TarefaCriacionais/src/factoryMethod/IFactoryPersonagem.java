package factoryMethod;

public interface IFactoryPersonagem {
	public Personagem criarPersonagem(String nome, String classe);
}
